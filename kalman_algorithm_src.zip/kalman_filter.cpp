#include "kalman_filter.hpp"

void KalmanFilter::setStateMatrix(Eigen::MatrixXd A){
    m_StateMtrx = A;
}
void KalmanFilter::setCntrlInputMatrix(Eigen::MatrixXd B){
    m_CtrlInputMtrx = B;
}
void KalmanFilter::setProcessNoiseCovMatrix(Eigen::MatrixXd Q){
    m_ProcNoiseCovMtrx = Q;
}
void KalmanFilter::setProcessCovMatrix(Eigen::MatrixXd P){
    m_ProcCovMtrx = P;
}
void KalmanFilter::setMeasurementNoiseCovMatrix(Eigen::MatrixXd R){
    m_MeasNoiseCovMtrx = R;
}
void KalmanFilter::setCntrlInputVector(Eigen::VectorXd u){
    m_CtrlVec = u;
}
void KalmanFilter::setIdentityMatrix(Eigen::MatrixXd I){
    m_IdentityMtrx = I;
}
void KalmanFilter::setObservationMatrix(Eigen::MatrixXd H){
    m_ObservationMtrx = H;
}
void KalmanFilter::setStateVector(Eigen::VectorXd x_state){
    m_StateVec = x_state;
}
void KalmanFilter::setMeasuredVector(Eigen::VectorXd x_meas){
    m_MeasuredVec = x_meas;
}    
Eigen::MatrixXd KalmanFilter::getProcessCovMatrix(){
    return m_ProcCovMtrx;
}
Eigen::MatrixXd KalmanFilter::getKalmanGain(){
    return m_KalmanGainMtrx;
}
Eigen::VectorXd KalmanFilter::getEstimatedVector(){
    return m_EstVec;
}
Eigen::VectorXd KalmanFilter::getStateVector(){
    return m_StateVec;
}

void KalmanFilter::predict(){
    m_EstVec = m_StateMtrx * m_StateVec + 
	m_CtrlInputMtrx * m_CtrlVec;
    m_PredictStateCovMtrx = m_StateMtrx * 
	m_ProcCovMtrx * m_StateMtrx.transpose() + m_ProcNoiseCovMtrx;
}
void KalmanFilter::measurementInput(){
    m_MeasureStateVec = m_ObservationMtrx * m_MeasuredVec;
}
void KalmanFilter::update(){
    const Eigen::MatrixXd S = m_PredictStateCovMtrx 
	* m_ObservationMtrx.transpose();
    const Eigen::MatrixXd T = m_ObservationMtrx 
	* m_PredictStateCovMtrx * m_ObservationMtrx.transpose() + m_MeasNoiseCovMtrx;
    m_KalmanGainMtrx = S * T.inverse() ;
    m_StateVec = m_EstVec + m_KalmanGainMtrx 
	* (m_MeasureStateVec - m_ObservationMtrx * m_StateVec);
    m_ProcCovMtrx = (m_IdentityMtrx - m_KalmanGainMtrx 
	* m_ObservationMtrx.transpose()) * m_PredictStateCovMtrx;
}
void KalmanFilter::summarized(){
    predict();
    measurementInput();
    update();
}
     


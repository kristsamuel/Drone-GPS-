


#include <string>
#include <assert.h>

namespace lps {

class kalman_filter_impl
{
private:
	double m_proc_noise_var;
	double m_meas_uncert;
	double m_x_nn;
	double m_est_uncert_nn;
	double m_x_nn1;
	double m_est_uncert_nn1;
	double m_kalman_gain;

private: 
	double get_kalman_gain(double est_uncert, double meas_uncert); 

public: 
	kalman_filter_impl();
	~kalman_filter_impl();
	void init(double estimate_error, double process_noise_variance, 
     		  double measurement_error, double initial_guess); 
	void update(double current_measurement); 
	void predict(double time = 0);
	double get_predicted_est() const; 
	double get_predicted_est_uncert() const; 
	double get_current_est() const;
	double get_current_est_uncert() const; 
};

}



#include "kalman_filter_impl.h"
#include <iostream>

namespace lps {


kalman_filter_impl::
kalman_filter_impl()
	: m_proc_noise_var(0.0) // process noise variance
	, m_meas_uncert(0.0)    // measurement uncertainity
	, m_x_nn(0.0)           // system state estimate
	, m_est_uncert_nn(0.0)  // estimate uncertainity
	, m_x_nn1(0.0)          // predicted system state
	, m_est_uncert_nn1(0.0) // predicted estimate uncertainity
	, m_kalman_gain(0.0)    // kalman_gain
{
}

kalman_filter_impl::
~kalman_filter_impl() {}
// Takes measured value, measurement uncertainity, 
// previous system state estimate, and estimate uncertainity
// Calculates current system state estimate, 
// and current state estimate uncertainity
void kalman_filter_impl::
update(double current_measurement) {
	float kalman_gain = get_kalman_gain(m_est_uncert_nn, m_meas_uncert);
	m_x_nn = m_x_nn1 + kalman_gain * (current_measurement - m_x_nn);
	m_est_uncert_nn = (1 - kalman_gain) * m_est_uncert_nn;
}

void kalman_filter_impl::
predict(double time) {
	// the second summable equals to velocity * time
	// TODO: find m_x_prev
	m_x_nn1 = m_x_nn; // + time * (m_x_nn - m_x_prev);
        m_est_uncert_nn = m_est_uncert_nn + m_proc_noise_var;
}

double kalman_filter_impl::
get_predicted_est() const {
	return m_x_nn1;
}

double kalman_filter_impl::
get_predicted_est_uncert() const {
	return m_est_uncert_nn;
}

double kalman_filter_impl::
get_current_est() const {
	return m_x_nn;
}

double kalman_filter_impl::
get_current_est_uncert() const {
	return m_est_uncert_nn;
}

double kalman_filter_impl::
get_kalman_gain(double est_uncert, double meas_uncert) {
	return est_uncert / (est_uncert + meas_uncert);
}

void kalman_filter_impl::
init(double estimate_error, double process_noise_variance, 
     double measurement_error, double initial_guess) {
	// error variance or estimate uncertainity
	m_est_uncert_nn = estimate_error * estimate_error; 
	m_proc_noise_var = process_noise_variance;
	// measurement uncertainity or measurement variance
	m_meas_uncert = measurement_error * measurement_error;
	m_x_nn = initial_guess;
}

}

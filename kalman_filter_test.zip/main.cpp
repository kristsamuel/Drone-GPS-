
// Headers from this project

// Headers from other projects
#include <controller/kalman_filter_impl.h>

// Headers from third party libraries

// Headers from standard libraries
#include <algorithm>
#include <cassert>
#include <fstream>
#include <iostream>
#include <math.h>

// Kalman filter model and values from: https://www.kalmanfilter.net/kalman1d.html, Example 8

void set_true_values(double* true_values) {
	//approximated values to be used for testing the KF
	true_values[0] = 50.479;
	true_values[1] = 51.025;
	true_values[2] = 51.5;
	true_values[3] = 53.003;
	true_values[4] = 52.494;
	true_values[5] = 54.002;
	true_values[6] = 53.499;
	true_values[7] = 54.006;
	true_values[8] = 54.498;
	true_values[9] = 54.991;
}

void set_measurement_values(double* meas_values) {
	//approximated values to be used for testing the KF
	meas_values[0] = 50.45;
	meas_values[1] = 50.967;
	meas_values[2] = 51.6;
	meas_values[3] = 52.106;
	meas_values[4] = 52.492;
	meas_values[5] = 52.819;
	meas_values[6] = 53.433;
	meas_values[7] = 54.007;
	meas_values[8] = 54.523;
	meas_values[9] = 54.99;
}

void filter_test() {
	double eps = 0.01;
	double true_values[10];
	double meas_values[10];
	set_true_values(true_values);
	set_measurement_values(meas_values);
	lps::kalman_filter_impl k;
	k.init(100.0, 0.15, 0.1, 10.0);
	
	k.predict();
	assert(fabs(k.get_predicted_est() - 10) < eps);
	assert(fabs(k.get_predicted_est_uncert() - 10000.15) < eps);
	
	k.update(meas_values[0]);
	assert(fabs(k.get_current_est() - 50.45) < eps);
	assert(fabs(k.get_current_est_uncert() - 0.01) < eps);
	k.predict();
	assert(fabs(k.get_predicted_est() - 50.45) < eps);
	assert(fabs(k.get_predicted_est_uncert() - 0.16) < eps);
	
	k.update(meas_values[1]);
	assert(fabs(k.get_current_est() - 50.94) < eps);
	assert(fabs(k.get_current_est_uncert() - 0.0094) < eps);
	k.predict();
	assert(fabs(k.get_predicted_est() - 50.94) < eps);
	assert(fabs(k.get_predicted_est_uncert() - 0.1594) < eps);

	k.update(meas_values[2]);
	assert(fabs(k.get_current_est() - 51.56) < eps);
	assert(fabs(k.get_current_est_uncert() - 0.0094) < eps);
	k.predict();
	assert(fabs(k.get_predicted_est() - 51.56) < eps);
	assert(fabs(k.get_predicted_est_uncert() - 0.1594) < eps);

	k.update(meas_values[3]);
	assert(fabs(k.get_current_est() - 52.07) < eps);
	assert(fabs(k.get_current_est_uncert() - 0.0094) < eps);
	k.predict();
	assert(fabs(k.get_predicted_est() - 52.07) < eps);
	assert(fabs(k.get_predicted_est_uncert() - 0.1594) < eps);
	
	k.update(meas_values[4]);
	assert(fabs(k.get_current_est() - 52.47) < eps);
	assert(fabs(k.get_current_est_uncert() - 0.0094) < eps);
	k.predict();
	assert(fabs(k.get_predicted_est() - 52.47) < eps);
	assert(fabs(k.get_predicted_est_uncert() - 0.1594) < eps);
	
	k.update(meas_values[5]);
	assert(fabs(k.get_current_est() - 52.8) < eps);
	assert(fabs(k.get_current_est_uncert() - 0.0094) < eps);
	k.predict();
	assert(fabs(k.get_predicted_est() - 52.8) < eps);
	assert(fabs(k.get_predicted_est_uncert() - 0.1594) < eps);
	
	k.update(meas_values[6]);
	assert(fabs(k.get_current_est() - 53.4) < eps);
	assert(fabs(k.get_current_est_uncert() - 0.0094) < eps);
	k.predict();
	assert(fabs(k.get_predicted_est() - 53.4) < eps);
	assert(fabs(k.get_predicted_est_uncert() - 0.1594) < eps);
	
	k.update(meas_values[7]);
	assert(fabs(k.get_current_est() - 53.97) < eps);
	assert(fabs(k.get_current_est_uncert() - 0.0094) < eps);
	k.predict();
	assert(fabs(k.get_predicted_est() - 53.97) < eps);
	assert(fabs(k.get_predicted_est_uncert() - 0.1594) < eps);
	
	k.update(meas_values[8]);
	assert(fabs(k.get_current_est() - 54.49) < eps);
	assert(fabs(k.get_current_est_uncert() - 0.0094) < eps);
	k.predict();
	assert(fabs(k.get_predicted_est() - 54.49) < eps);
	assert(fabs(k.get_predicted_est_uncert() - 0.1594) < eps);
	
	k.update(meas_values[9]);
	assert(fabs(k.get_current_est() - 54.96) < eps);
	assert(fabs(k.get_current_est_uncert() - 0.0094) < eps);
	k.predict();
	std::cout << k.get_predicted_est() - 54.96 << std::endl;
	assert(fabs(k.get_predicted_est() - 54.96) < eps);
	assert(fabs(k.get_predicted_est_uncert() - 0.1594) < eps);
        std::cout << "PASSED" << std::endl;	
}

int main()
{
    filter_test();
	return 0;
}

// vim:et:tabstop=8:shiftwidth=8:cindent:fo=croq:textwidth=80:

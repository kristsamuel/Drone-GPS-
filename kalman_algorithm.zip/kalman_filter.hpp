#ifndef KALMAN_CLASS_H
#define KALMAN_CLASS_H
#include <Eigen/Dense> //included for matrices and vactors
#include <iostream>
class KalmanFilter
{
    public:    
        /* State matrix setter
         * param A is the state matrix with dimension nxn
         */
        void setStateMatrix(Eigen::MatrixXd A);
        /* Control input matrix setter
         * param B is the control input matrix with dimension nxm
         */
        void setCntrlInputMatrix(Eigen::MatrixXd B);
        /* Process noise covariance matrix setter
         * param Q is the process noise covariance matrix with dimension nxn
         */
        void setProcessNoiseCovMatrix(Eigen::MatrixXd Q);
        /* Process noise covariance matrix setter 
         * param P is the state error covariance matrix with dimension nxn
         */
        void setProcessCovMatrix(Eigen::MatrixXd P);
        /* Measurement Noise Covariance Matrix setter
         * param R is the measurement noise covariance matrix with dimension lxl
         */
        void setMeasurementNoiseCovMatrix(Eigen::MatrixXd R);
        /* Control input vector setter
         * param u is the control input vector with dimension m
         */
        void setCntrlInputVector(Eigen::VectorXd u);
        /* Identity matrix setter
         * param I is the identity matrix with dimension nxn
         */
        void setIdentityMatrix(Eigen::MatrixXd I);
        /* State Vector setter
         * Param x_state is state vector with dimension n
         */
        void setStateVector(Eigen::VectorXd x_state);
        /* Measured Vector setter
         * Param x_meas is measured vector with dimension n
         * */
        void setMeasuredVector(Eigen::VectorXd x_meas);
        /* H matrix setter
         * Param H is observation matrix with dimension nxl
         */
        void setObservationMatrix(Eigen::MatrixXd H);
        /* Process covariance matrix getter
         * return m_ProcCovMtrx
         */
        Eigen::MatrixXd getProcessCovMatrix();//P
        /* Kalman gain getter
         * return m_KalmanGain
         */
        Eigen::MatrixXd getKalmanGain();
        /* Estimated vector getter
         * return m_EstVec
         */
        Eigen::VectorXd getEstimatedVector();
        /* State vector getter
         * return m_StateVec
         */
        Eigen::VectorXd getStateVector();
        /* Prediction state function 
         */
        void predict();
        /* Measurement input function
         */
        void measurementInput();
        /* Update state function
         * */
        void update();
        /* Summaraized function of functions
         * predict(),measurementInput(),update()
         */
        void summarized();



    private:
        Eigen::MatrixXd m_StateMtrx;           //A
        Eigen::MatrixXd m_CtrlInputMtrx;       //B
        Eigen::MatrixXd m_ProcNoiseCovMtrx;    //Q
        Eigen::MatrixXd m_ObservationMtrx;     //
        Eigen::MatrixXd m_ProcCovMtrx;         //P
        Eigen::MatrixXd m_MeasNoiseCovMtrx;    //R
        Eigen::MatrixXd m_IdentityMtrx;        //I
        Eigen::MatrixXd m_KalmanGainMtrx;      //K
        Eigen::VectorXd m_StateVec;            //x_state
        Eigen::VectorXd m_EstVec;              //x_est
        Eigen::VectorXd m_CtrlVec;             //u
        Eigen::MatrixXd m_PredictStateCovMtrx; //p_pred
        Eigen::VectorXd m_MeasureStateVec;     //y
        Eigen::VectorXd m_MeasuredVec;         //x_meas
};
#endif
